"use client";
import { useState, useEffect } from "react";
import { db } from "../../lib/firebase";
import { collection, getDocs } from "firebase/firestore";
import jsPDF from "jspdf";
import "jspdf-autotable";

export default function Admin() {
  const [auth, setAuth] = useState({ user: "", pass: "" });
  const [isLogged, setIsLogged] = useState(false);
  const [jugadores, setJugadores] = useState([]);
  const [equipos, setEquipos] = useState([]);
  const [loading, setLoading] = useState(false);

  const login = (e) => {
    e.preventDefault();
    if (auth.user === "carlosrubi" && auth.pass === "22211206") {
      setIsLogged(true);
      fetchData();
    } else {
      alert("Credenciales incorrectas");
    }
  };

  const fetchData = async () => {
    setLoading(true);
    const jSnapshot = await getDocs(collection(db, "jugadores"));
    const eSnapshot = await getDocs(collection(db, "equipos"));
    
    setJugadores(jSnapshot.docs.map(d => d.data()).sort((a, b) => a.nombreEquipo.localeCompare(b.nombreEquipo)));
    setEquipos(eSnapshot.docs.map(d => d.data()));
    setLoading(false);
  };

  const descargarPDF = () => {
    const doc = new jsPDF();
    doc.text("Listado de Jugadores - MECAFUT Q4 2026", 14, 15);
    doc.autoTable({
      startY: 25,
      head: [["#", "Equipo", "Nombre", "Cuenta", "Carrera"]],
      body: jugadores.map((j, i) => [i + 1, j.nombreEquipo, j.nombre, j.cuenta, j.carrera]),
      styles: { fontSize: 8 },
      headStyles: { fillColor: [30, 58, 138] }
    });
    doc.save("jugadores_mecafut.pdf");
  };

  if (!isLogged) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center">
        <form onSubmit={login} className="bg-white p-8 rounded shadow-md w-96 text-center">
          <h2 className="text-xl font-bold mb-6 text-blue-900">Acceso Administrativo</h2>
          <input required placeholder="Usuario" className="w-full border p-2 mb-4 rounded" onChange={e => setAuth({...auth, user: e.target.value})} />
          <input required type="password" placeholder="Contraseña" className="w-full border p-2 mb-6 rounded" onChange={e => setAuth({...auth, pass: e.target.value})} />
          <button type="submit" className="w-full bg-blue-900 text-white font-bold py-2 rounded">Ingresar</button>
        </form>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-blue-900">Panel Administrativo</h1>
        <div className="flex gap-4">
          <div className="text-sm text-right bg-blue-50 p-2 rounded">
            <p><strong>Equipos:</strong> {equipos.length}</p>
            <p><strong>Jugadores:</strong> {jugadores.length}</p>
          </div>
          <button onClick={descargarPDF} className="bg-red-600 text-white px-4 py-2 rounded font-bold h-fit my-auto">
            Descargar PDF
          </button>
        </div>
      </div>

      {loading ? <p>Cargando...</p> : (
        <div className="overflow-x-auto">
          <table className="w-full bg-white border shadow-sm text-sm text-left">
            <thead className="bg-blue-900 text-white">
              <tr><th className="p-3">Equipo</th><th className="p-3">Jugador</th><th className="p-3">Cuenta</th><th className="p-3">Carrera</th></tr>
            </thead>
            <tbody>
              {jugadores.map((j, i) => (
                <tr key={i} className="border-b hover:bg-gray-50">
                  <td className="p-3 font-semibold">{j.nombreEquipo}</td>
                  <td className="p-3">{j.nombre}</td>
                  <td className="p-3">{j.cuenta}</td>
                  <td className="p-3">{j.carrera}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
