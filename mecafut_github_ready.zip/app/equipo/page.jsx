"use client";
import { useState } from "react";
import { db } from "../../lib/firebase";
import { collection, query, where, getDocs } from "firebase/firestore";

export default function VerEquipo() {
  const [codigo, setCodigo] = useState("");
  const [equipo, setEquipo] = useState(null);
  const [jugadores, setJugadores] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const buscarEquipo = async (e) => {
    e.preventDefault();
    setLoading(true); setError(""); setEquipo(null);
    
    try {
      const q = query(collection(db, "equipos"), where("codigoAcceso", "==", codigo));
      const snapshot = await getDocs(q);
      
      if (snapshot.empty) throw new Error("No se encontró ningún equipo con ese código");
      
      const equipoData = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
      setEquipo(equipoData);

      const qJugadores = query(collection(db, "jugadores"), where("equipoId", "==", equipoData.id));
      const jSnapshot = await getDocs(qJugadores);
      setJugadores(jSnapshot.docs.map(d => d.data()));
    } catch (err) {
      setError(err.message);
    }
    setLoading(false);
  };

  return (
    <div className="max-w-3xl mx-auto p-6">
      <div className="bg-white p-6 rounded shadow text-center">
        <h2 className="text-xl font-bold mb-4">Visualizar mi Inscripción</h2>
        <form onSubmit={buscarEquipo} className="flex gap-2 max-w-md mx-auto">
          <input required placeholder="Ingresa tu código de 8 dígitos" className="border p-2 rounded flex-1 text-center font-mono" value={codigo} onChange={e => setCodigo(e.target.value)} />
          <button type="submit" disabled={loading} className="bg-blue-900 text-white px-4 rounded font-bold">{loading ? "..." : "Buscar"}</button>
        </form>
        {error && <p className="text-red-600 mt-4 font-bold">{error}</p>}
      </div>

      {equipo && (
        <div className="mt-6 bg-white p-6 rounded shadow">
          <h3 className="text-2xl font-bold text-blue-900 border-b pb-2 mb-4">{equipo.nombre}</h3>
          <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
            <p><strong>Capitán:</strong> {equipo.capitan.nombre}</p>
            <p><strong>Categoría:</strong> {equipo.categoria}</p>
            <p><strong>Docente:</strong> {equipo.docente}</p>
            <p><strong>Uniforme:</strong> {equipo.color}</p>
          </div>
          
          <h4 className="font-bold mb-2">Jugadores Inscritos ({jugadores.length})</h4>
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-100"><th className="p-2 border">Nombre</th><th className="p-2 border">Cuenta</th><th className="p-2 border">Carrera</th></tr>
            </thead>
            <tbody>
              {jugadores.map((j, i) => (
                <tr key={i}><td className="p-2 border">{j.nombre}</td><td className="p-2 border">{j.cuenta}</td><td className="p-2 border">{j.carrera}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
