import './globals.css';
import Link from 'next/link';

export const metadata = {
  title: 'MECAFUT Q4 2026',
  description: 'Inscripciones MECAFUT Q4 2026 - Ing. Mecatrónica',
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body className="bg-gray-50 min-h-screen">
        <nav className="bg-blue-900 text-white p-4 shadow-md">
          <div className="max-w-6xl mx-auto flex flex-wrap justify-between items-center">
            <h1 className="text-xl font-bold">⚽ MECAFUT Q4 2026</h1>
            <div className="flex gap-4 mt-2 sm:mt-0">
              <Link href="/" className="hover:text-blue-200">Inscribir Equipo</Link>
              <Link href="/equipo" className="hover:text-blue-200">Ver Equipo</Link>
              <Link href="/admin" className="hover:text-blue-200">Administrador</Link>
            </div>
          </div>
        </nav>
        {children}
      </body>
    </html>
  );
}
