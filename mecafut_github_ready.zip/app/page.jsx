"use client";
import { useState } from "react";
import { db } from "../lib/firebase";
import { collection, query, where, getDocs, writeBatch, doc } from "firebase/firestore";

const DOCENTES = ["Ing. Jared Sauceda", "Ing. Orlando Aguiluz", "Ing. Ricardo Maldonado", "Ing. José Luis Ordoñez", "Ing. Pedro Vásquez", "Ing. Hegel López", "Ing. David Gonzales", "Ing. Juan Miguel Mejía", "Ing. Roque López", "Ing. Josué Pérez", "Ing. Winder Matamoros", "Ing. Elvin Ledezma", "Ing. André Colindres", "Ing. Cristhyan Rivera", "Ing. Vielka Barahona"];
const CARRERAS = ["Ingeniería Mecatrónica", "Ingeniería Industrial", "Ingeniería en Sistemas", "Ingeniería Biomédica", "Ingeniería Civil", "Ingeniería en Telecomunicaciones", "Ingeniería en Energía", "Arquitectura"];

export default function Registro() {
  const [capitan, setCapitan] = useState({ nombre: "", cuenta: "", telefono: "" });
  const [equipo, setEquipo] = useState({ nombre: "", docente: DOCENTES[0], categoria: "Masculino", color: "" });
  const [jugadores, setJugadores] = useState(Array(10).fill({ nombre: "", cuenta: "", carrera: CARRERAS[0] }));
  const [comprobante, setComprobante] = useState(null);
  const [loading, setLoading] = useState(false);
  const [mensaje, setMensaje] = useState("");
  const [codigoGenerado, setCodigoGenerado] = useState("");

  const handleJugadorChange = (index, field, value) => {
    const nuevosJugadores = [...jugadores];
    nuevosJugadores[index] = { ...nuevosJugadores[index], [field]: value };
    setJugadores(nuevosJugadores);
  };

  const agregarJugador = () => { if (jugadores.length < 25) setJugadores([...jugadores, { nombre: "", cuenta: "", carrera: CARRERAS[0] }]); };

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); setMensaje(""); setCodigoGenerado("");

    try {
      const cuentasFormulario = jugadores.map(j => j.cuenta).filter(c => c.trim() !== "");
      if (new Set(cuentasFormulario).size !== cuentasFormulario.length) {
        throw new Error("Hay números de cuenta duplicados dentro de tu mismo equipo.");
      }

      for (let i = 0; i < cuentasFormulario.length; i += 10) {
        const chunk = cuentasFormulario.slice(i, i + 10);
        if (chunk.length > 0) {
          const q = query(collection(db, "jugadores"), where("cuenta", "in", chunk));
          const querySnapshot = await getDocs(q);
          if (!querySnapshot.empty) {
            const duplicados = querySnapshot.docs.map(d => d.data().cuenta).join(", ");
            throw new Error(`Cuentas ya inscritas en otro equipo: ${duplicados}`);
          }
        }
      }

      const codigoAcceso = Math.random().toString().slice(2, 10);
      const batch = writeBatch(db);
      const equipoRef = doc(collection(db, "equipos"));
      
      batch.set(equipoRef, {
        ...equipo,
        capitan,
        codigoAcceso,
        comprobanteAdjunto: comprobante ? true : false,
        fechaRegistro: new Date().toISOString()
      });

      jugadores.forEach((jugador) => {
        if(jugador.nombre && jugador.cuenta) {
          const jugadorRef = doc(collection(db, "jugadores"));
          batch.set(jugadorRef, { ...jugador, equipoId: equipoRef.id, nombreEquipo: equipo.nombre });
        }
      });

      await batch.commit();
      setMensaje("¡Equipo inscrito exitosamente!");
      setCodigoGenerado(codigoAcceso);
    } catch (error) {
      setMensaje(error.message);
    }
    setLoading(false);
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6 text-center text-blue-900">Inscripción de Equipo</h2>
      
      {mensaje && <div className={`mb-4 p-4 text-center font-bold rounded ${codigoGenerado ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{mensaje}</div>}
      
      {codigoGenerado && (
        <div className="bg-yellow-100 border-l-4 border-yellow-500 p-4 mb-6">
          <p className="font-bold text-yellow-800">¡Guarda este código para ver tu equipo!</p>
          <p className="text-2xl tracking-widest font-mono mt-2">{codigoGenerado}</p>
        </div>
      )}

      <form onSubmit={onSubmit} className="space-y-6">
        {/* CAPITÁN */}
        <section className="bg-white p-6 rounded shadow">
          <h3 className="font-bold mb-4">1. Datos del Capitán</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input required placeholder="Nombre" className="border p-2 rounded" onChange={e => setCapitan({...capitan, nombre: e.target.value})} />
            <input required placeholder="Cuenta" className="border p-2 rounded" onChange={e => setCapitan({...capitan, cuenta: e.target.value})} />
            <input required type="tel" placeholder="Teléfono" className="border p-2 rounded" onChange={e => setCapitan({...capitan, telefono: e.target.value})} />
          </div>
        </section>

        {/* EQUIPO */}
        <section className="bg-white p-6 rounded shadow">
          <h3 className="font-bold mb-4">2. Datos del Equipo</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input required placeholder="Nombre Equipo" className="border p-2 rounded" onChange={e => setEquipo({...equipo, nombre: e.target.value})} />
            <select className="border p-2 rounded" onChange={e => setEquipo({...equipo, docente: e.target.value})}>
              {DOCENTES.map(doc => <option key={doc} value={doc}>{doc}</option>)}
            </select>
            <select className="border p-2 rounded" onChange={e => setEquipo({...equipo, categoria: e.target.value})}>
              <option value="Masculino">Masculino</option>
              <option value="Femenino">Femenino</option>
            </select>
            <input required placeholder="Color uniforme" className="border p-2 rounded" onChange={e => setEquipo({...equipo, color: e.target.value})} />
            <div className="col-span-1 md:col-span-2 mt-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Comprobante de Pago (Imagen/PDF)</label>
              <input type="file" required className="border p-2 rounded w-full" onChange={e => setComprobante(e.target.files[0])} />
            </div>
          </div>
        </section>

        {/* JUGADORES */}
        <section className="bg-white p-6 rounded shadow">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold">3. Jugadores ({jugadores.length}/25)</h3>
            {jugadores.length < 25 && <button type="button" onClick={agregarJugador} className="bg-green-600 text-white px-3 py-1 rounded text-sm">+ Agregar</button>}
          </div>
          <div className="space-y-3">
            {jugadores.map((j, i) => (
              <div key={i} className="grid grid-cols-1 md:grid-cols-3 gap-3 p-3 border rounded bg-gray-50">
                <input required placeholder={`Jugador ${i + 1}`} value={j.nombre} className="border p-2 rounded text-sm" onChange={e => handleJugadorChange(i, "nombre", e.target.value)} />
                <input required placeholder="Cuenta" value={j.cuenta} className="border p-2 rounded text-sm" onChange={e => handleJugadorChange(i, "cuenta", e.target.value)} />
                <select className="border p-2 rounded text-sm" value={j.carrera} onChange={e => handleJugadorChange(i, "carrera", e.target.value)}>
                  {CARRERAS.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            ))}
          </div>
        </section>

        <button disabled={loading} type="submit" className="w-full bg-blue-900 text-white font-bold py-4 rounded hover:bg-blue-800">
          {loading ? "Procesando..." : "Finalizar Inscripción"}
        </button>
      </form>
    </div>
  );
}
